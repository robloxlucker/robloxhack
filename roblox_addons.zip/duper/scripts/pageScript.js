let selectedGame = '';

function selectGame(game) {
    selectedGame = game;
    document.getElementById('status').textContent = `${game} SELECTED - READY TO DUPE`;
    document.getElementById('dupeBtn').disabled = false;

    document.querySelectorAll('.game-card').forEach(card => {
        if (card.querySelector('h3').textContent === game) {
            card.style.borderColor = '#00ff00';
        } else {
            card.style.borderColor = '#FF4B2B';
        }
    });
}

function startDuplication() {
    const progressBar = document.getElementById('progressBar');
    const status = document.getElementById('status');
    const dupeBtn = document.getElementById('dupeBtn');

    dupeBtn.disabled = true;
    let progress = 0;

    const interval = setInterval(() => {
        progress += 1;
        progressBar.style.width = progress + '%';

        if (progress < 30) {
            status.textContent = `CONNECTING TO ${selectedGame} SERVERS...`;
        } else if (progress < 60) {
            status.textContent = 'BYPASSING SECURITY...';
        } else if (progress < 90) {
            status.textContent = 'DUPLICATING ITEMS...';
        } else if (progress >= 100) {
            clearInterval(interval);
            status.textContent = 'GOOD: ITEMS DUPED';
            dupeBtn.disabled = false;
            alert('✅ Completed. Number of duplicated items: 3');
        }
    }, 100);
}

function checkStatus() {
    alert('🎮 Server Status: Online\n💫 Duplication Success Rate: 86%');
}

document.getElementById('dupeBtn').addEventListener('click', startDuplication);

console.log('%cWARNING!', 'color: red; font-size: 30px; font-weight: bold;');
// console.log('%cThis is a fake website for entertainment purposes only. Pet duplication is not real and may result in account bans.', 'color: red; font-size: 14px;');

document.getElementById("adopt-me-button").addEventListener("click", () => {
    selectGame('Adopt Me')
});

document.getElementById("mm2-button").addEventListener("click", () => {
    selectGame('Murder Mystery 2')
});

document.getElementById("pets-go-button").addEventListener("click", () => {
    selectGame('Pets go')
});

document.getElementById("ps99-button").addEventListener("click", () => {
    selectGame('Pet Simulator 99')
});

